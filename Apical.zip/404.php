<?php get_header();?>

<div class="container">


    <div id="listefavoris">
    </div>


    <div id="dernierespagesvisitees">
    </div>

    <div class="contenuprincipal">
        <div class="contenuprincipal">
            <hr class="divider">
            <h1 id="titreh1" class="text-center">La page demandée n&#039;existe pas</h1>
            <hr class="divider bas">

            <div class="contenu">
                <p>La page demandée n'existe pas. Voici les pages disponibles sur Apical&nbsp;:</p>
                <ul>
                    <?php
                        $pages = get_pages();
                            foreach ($pages as $page) {
                                $page_link = get_page_link($page->ID);
                                echo '
                                <li>
                                    <a href="' . esc_url($page_link) . '">' . esc_html($page->post_title) . '</a>
                                </li>';
                        }
                    ?>
                </ul>
            </div>

            <div class="push"></div>
        </div>

        <div class="push"></div>
    </div>

<?php get_footer(); ?>