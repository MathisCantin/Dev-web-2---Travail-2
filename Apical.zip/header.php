<!DOCTYPE html>
<html lang="fr-CA">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-5HQFPLZYQK"></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-5HQFPLZYQK');
    </script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Contenu de la formation  PUB020&amp;nbsp;: WordPress sur Apical.">
    <meta name="author" content="Christiane Lagacé : https://christianelagace.com">
    <meta name="csrf-token" id="csrf-token" content="yWrCe67B8U83rGjdEnfm6lrn4PdqHIEJnteTYKc8">

    <title>Apical | Formation PUB020 : WordPress</title>

    <link rel="apple-touch-icon" sizes="180x180" href="https://apical.xyz/apple-touch-icon.png">
    <link rel="mask-icon" href="https://apical.xyz/safari-pinned-tab.svg" color="#3543a0">
    <meta name="msapplication-TileColor" content="#2b5797">
    <meta name="theme-color" content="#ffffff">
    <meta name="robots" content="noodp">

    <script data-ad-client="ca-pub-0968524214519104" async
        src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    <link
        href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Homemade+Apple" rel="stylesheet">

    <?php wp_head(); ?>
</head>

<body id="messtyles">
    <div class="aucunepubauto">
        <div class="logo fix-menu" id="zoneentete">
            <div class="container">
                <div class="avant"></div>
                <div class="apres">
                    <div id="menuicones" class="porteuroffset fix-menu" data-verticaloffset="47"
                        data-horizontaloffset="0">
                        <a href="/"><img
                                src="<?= get_template_directory_uri() . '/assets/medias/commun/Accueil-MenuSecondaire.svg'?>"
                                alt="Accueil" title="Accueil">
                        </a>
                        <a href="/">
                            <img src="<?= get_template_directory_uri() . '/assets/medias/commun/Rechercher-MenuSecondaire.svg'?>"
                                alt="Recherche" title="Rechercher">
                        </a>
                        <a id="boutonAuthentification" class="ouvrirpopupchristiane ouvrirpopupauthentification">
                            <img src="<?= get_template_directory_uri() . '/assets/medias/commun/Login-MenuSecondaire.svg'?>"
                                alt="Authentification" title="Authentification">
                        </a>
                    </div>
                </div>
                <div class="centre">
                    <a href="index.php">
                        <img src="<?= get_template_directory_uri() . '/assets/medias/fr/LogoApical-blanc.svg'?>"
                            alt="Apical, ma plateforme d'apprentissage">
                    </a>
                </div>
            </div>
        </div>

        <nav class="navbar navbar-expand-lg navbar-light py-lg-3" id="mainNav">
            <div class="container">
                <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none"
                    href="wordpress.html#">Apical</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                    aria-controls="navbarResponsive" aria-expanded="false" aria-label="Basculer">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">

                    <ul class="navbar-nav mx-auto">
                        <?php
                            $pages = get_pages();
                            foreach ($pages as $page) {
                                $page_link = get_page_link($page->ID);
                                echo '
                                <li class="nav-item px-lg-4">
                                    <a href="' . esc_url($page_link) . '" class=" nav-link text-uppercase text-expanded">' . esc_html($page->post_title) . '</a>
                                </li>';
                            }
                        ?>
                    </ul>


                    <div class="iconespourmobile">
                        <div id="menuicones" class="porteuroffset fix-menu" data-verticaloffset="47"
                            data-horizontaloffset="0">
                            <a href="/"><img
                                    src="<?= get_template_directory_uri() . '/assets/medias/commun/Accueil-MenuSecondaire.svg'?>"
                                    alt="Accueil" title="Accueil">
                            </a>
                            <a href="/">
                                <img src="<?= get_template_directory_uri() . '/assets/medias/commun/Rechercher-MenuSecondaire.svg'?>"
                                    alt="Recherche" title="Rechercher">
                            </a>
                            <a id="boutonAuthentification" class="ouvrirpopupchristiane ouvrirpopupauthentification">
                                <img src="<?= get_template_directory_uri() . '/assets/medias/commun/Login-MenuSecondaire.svg'?>"
                                    alt="Authentification" title="Authentification">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>