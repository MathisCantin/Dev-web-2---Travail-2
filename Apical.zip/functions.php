<?php

function enqueue_my_assets() {
    wp_enqueue_style('my-style', get_template_directory_uri() . '/assets/css/apical.css');
    wp_enqueue_script('my-script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), '', true);
}
add_action('wp_enqueue_scripts', 'enqueue_my_assets');


/* 
function enqueue_apical_assets() {
    // Enqueue Styles
    wp_enqueue_style('apical-style', get_template_directory_uri() . '/assets/css/apical.css', array(), '1.0.0');

    // Enqueue Scripts
    wp_enqueue_script('jquery');    
    wp_enqueue_script('apical-script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'enqueue_apical_assets'); */



/* function my_theme_enqueue_styles() {
    wp_enqueue_style( 'my_theme_style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );

function theme_scripts() {
    wp_enqueue_script( 'my-script', get_template_directory_uri() . '/script.js', array(), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'theme_scripts' ); */
