<?php

function enqueue_my_assets() {
    wp_enqueue_style('my-style', get_template_directory_uri() . '/assets/css/apical.css');
    wp_enqueue_script('my-script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_my_assets');

function custom_login_handler() {
    if (isset($_POST['custom-login-nonce']) && wp_verify_nonce($_POST['custom-login-nonce'], 'custom-login')) {
        $login_data = array(
            'user_login' => $_POST['log'],
            'user_password' => $_POST['pwd'],
            'remember' => isset($_POST['rememberme']) ? true : false,
        );

        $user_verify = wp_signon($login_data, false);
        if (is_wp_error($user_verify)) {

            wp_redirect(home_url());
            exit;
        } else {
            
            wp_redirect(admin_url());
            exit;
        }
    }
}

add_action('admin_post_custom_login', 'custom_login_handler');
add_action('admin_post_nopriv_custom_login', 'custom_login_handler');
