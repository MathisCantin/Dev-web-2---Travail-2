<footer>
    <div class="container">
        <div class="row">
            <div class="col text-center">© 2023 Tous droits réservés.</div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col text-center">Conception et développement du thème : <span class="auteur"><a
                        target="_blank">Mathis Cantin</a></span></div>
        </div>
    </div>
    <div class="container">
        <p class="centrer">
            Je suis étudiant au Cégep de Victoriaville en Technique informatique et
            ce thème m'a été donnée comme travail #2 en Développement Web 2.
        </p>
    </div>
    <div class="container">
        <div class="row text-center">
            <div class="col text-center mt-3">
                <a class="btn btn-primary" href="https://mathiscantin.ca/">Écrivez-moi&nbsp;! </a>
            </div>
        </div>
    </div>
</footer>

<div class="popupchristiane" id="popuprecherche">
    <form method="get" action="https://apical.xyz/rechercherFormationsPagesAjax">
        <input name="rechercher" type="text" id="rechercher" placeholder="Rechercher" required>
        <a id="soumettrerecherche" href="wordpress.html#">
            <img src="<?= get_template_directory_uri() . '/assets/medias/commun/BoutonRechercher.svg' ?>"
                class="boutonrechercher" title="Rechercher dans tout le site" alt="Soumettre">
        </a>
    </form>
    <span class="boutonrefermer"></span>
</div>
<div class="popupchristiane" id="popupauthentification">
    <div id="menuusager" class="cache">
        <p><label id="prenomnomfamille"></label></p>
        <a class="btn btn-secondary" href="https://apical.xyz/usagers/-1/modification">Profil</a>
        <a class="btn btn-secondary" id="deconnecter" href="wordpress.html#">Déconnecter</a>
    </div>
    <div id="formulaireauthentification">
        <span id="messageauthentification"></span>
        <form method="post" action="https://apical.xyz/usagers/authentifier" class='form-horizontal'>
            <input type="hidden" name="_token" value="yWrCe67B8U83rGjdEnfm6lrn4PdqHIEJnteTYKc8">
            <div class="form-group row">

                <label for="login" class="control-label col-sm-5 requis">Usager: </label>
                <div class=col-sm-6>
                    <input type="text" class="form-control" name="login" id="login" autofocus>
                </div>
            </div>
            <div class="form-group row">
                <label for="motdepasse" class="control-label col-sm-5 requis">Mot de passe: </label>
                <div class=col-sm-6>
                    <input type="password" class="form-control" name="motdepasse" id="motdepasse">
                </div>
            </div>
            <div class="form-group row">
                <div class="control-label col-sm-5"></div>
                <div class="col-sm-6">
                    <div class="form-check">
                        <label for="resterconnecte" class="form-check-label" checked>
                            <input class="form-check-input" type="checkbox" id="resterconnecte" name="resterconnecte">
                            Rester connecté
                        </label>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <div class="control-label col-sm-5"></div>
                <div class="col-sm-6">
                    <a id="soumettreauthentification" class="btn btn-secondary" href="wordpress.html#">Soumettre</a>
                </div>
            </div>
            <div class="form-group row">
                <div class="control-label col-sm-5"></div>
                <div class="col-sm-6">
                    <a href="https://apical.xyz/usagers/creation">Nouvel usager</a>
                </div>
            </div>
        </form>
    </div>
    <span class="boutonrefermer"></span>
</div>
<div class="popupchristiane" id="popupbienvenue"></div>

<?php wp_footer(); ?>

</body>

</html>