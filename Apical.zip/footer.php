<div class="publicite baspage">
    <div class="pubhebergement">
        <p>Site fièrement hébergé chez <a href="http://www.a2hosting.com?aid=5ca65a17be949" target="_top">A2
                Hosting</a>.</p>
        <p><a href="https://www.a2hosting.com?aid=5ca65a17be949&amp;bid=ed1c4a67" target="_top"><img alt="" title=""
                    width="728" height="90" /></a><img style="border:0" width="1" height="1" alt="" /></p>
    </div>
</div>
</div>

<footer>
    <div class="container">
        <div class="row">
            <div class="col text-center">© 2023 Tous droits réservés.</div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col text-center">Conception et développement du thème : <span class="auteur"><a
                        target="_blank">Mathis Cantin</a></span></div>
        </div>
    </div>
    <div class="container">
        <p class="centrer">Je suis étudiant au Cégep de Victoriaville en Technique informatique et ce thème m'a été
            donnée comme
            travail #2 en Développement Web 2.</p>
    </div>
    <div class="container">
        <div class="row text-center">
            <div class="col text-center mt-3">
                <a class="btn btn-primary"
                    href="https://apical.xyz/contact?de=https%3A%2F%2Fapical.xyz%2Fformations%2Fwordpress">Écrivez-moi&nbsp;!</a>
            </div>
        </div>
    </div>
</footer>

<div class="popupchristiane" id="popuprecherche">
    <form method="get" action="https://apical.xyz/rechercherFormationsPagesAjax">

        <input name="rechercher" type="text" id="rechercher" placeholder="Rechercher" required />
        <a id="soumettrerecherche" href="wordpress.html#"><img
                src="wp-content/themes/Apical/assets/medias/commun/BoutonRechercher.svg" class="boutonrechercher"
                title="Rechercher dans tout le site" alt="Soumettre" /></a>
    </form>
    <span class="boutonrefermer"></span>
</div>
<div class="popupchristiane" id="popupauthentification">
    <div id="menuusager" class="cache">

        <p><label id="prenomnomfamille"></label></p>
        <a class="btn btn-secondary" href="https://apical.xyz/usagers/-1/modification">Profil</a>
        <a class="btn btn-secondary" id="deconnecter" href="wordpress.html#">Déconnecter</a>
    </div>

    <div id="formulaireauthentification">
        <span id="messageauthentification"></span>
        <form method="post" action="https://apical.xyz/usagers/authentifier" class='form-horizontal'>
            <input type="hidden" name="_token" value="yWrCe67B8U83rGjdEnfm6lrn4PdqHIEJnteTYKc8">

            <div class="form-group row">

                <label for="login" class="control-label col-sm-5 requis">Usager: </label>
                <div class=col-sm-6>
                    <input type="text" class="form-control" name="login" id="login" autofocus>
                </div>
            </div>
            <div class="form-group row">
                <label for="motdepasse" class="control-label col-sm-5 requis">Mot de passe: </label>
                <div class=col-sm-6>
                    <input type="password" class="form-control" name="motdepasse" id="motdepasse">
                </div>
            </div>
            <div class="form-group row">
                <div class="control-label col-sm-5"></div>
                <div class="col-sm-6">
                    <div class="form-check">
                        <label for="resterconnecte" class="form-check-label" checked>
                            <input class="form-check-input" type="checkbox" id="resterconnecte" name="resterconnecte">
                            Rester connecté
                        </label>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <div class="control-label col-sm-5"></div>
                <div class="col-sm-6">
                    <a id="soumettreauthentification" class="btn btn-secondary" href="wordpress.html#">Soumettre</a>
                </div>
            </div>
            <div class="form-group row">
                <div class="control-label col-sm-5"></div>
                <div class="col-sm-6">
                    <a href="https://apical.xyz/usagers/creation">Nouvel usager</a>
                </div>
            </div>
        </form>

    </div>


    <span class="boutonrefermer"></span>
</div>
<div class="popupchristiane" id="popupbienvenue"></div>

<script>
(function() {
    ('.reinitialiserCookiesMenuFormations').click(function(event) {
        event.preventDefault();
        var jqxhr = $.get("https://apical.xyz/reinitialiserCookiesMenuFormations")
            .done(function(response, textStatus, jqXHR) {
                $('.consulterecemment').remove();
                afficherPopupInformation(
                    'La liste des dernières formations consultées a été réinitialisée avec succès !'
                );
            })
            .fail(function(jqXHR, textStatus, errorThrown) {
                afficherPopupErreur(
                    'Un problème empêche la réinitialisation de la liste des dernières formations consultées.'
                );
            });
    });
});
</script>

<script>
(function() {

    // *********************************************************************************************
    // *** Drag'n drop *****************************************************************************
    // *********************************************************************************************
    // todo : faire le drag'n drop pour les fiches.

    ('#dragchapitres').sortable({
        handle: $('.glisser'),
        cursor: 'move',
        update: function(event, ui) {
            var chapitresNouvelOrdre = $(this).sortable(
                'serialize'
            ); // chaîne au format "dragchapitre[]=10&dragchapitre[]=8&dragchapitre[]=9"

            $.ajax({
                data: chapitresNouvelOrdre,
                type: 'POST',
                url: '/chapitres/reordonnerChapitres'
            });
        }
    });

    // **************************************************************************************************
    // *** Génération de la liste des fiches de tous les chapitres lorsqu'on clique sur Tout développer *
    // **************************************************************************************************
    $("#chapitresformation #developperreduire").click(function() {
        // s'il y a une balise avec la classe encoursdegeneration dans un panel-body, c'est que la liste complète n'a pas été générée
        // if ($('#chapitresformation .panel-group .encoursdegeneration').length) {   // la classe panel-group n'a pas d'équivalent en Bootstrap 4...
        if ($('#chapitresformation .encoursdegeneration').length) {
            // retrouve le formation_id
            var formation_id = $('#chapitresformation').attr('data-formation-id');
            // génère la liste
            listeFichesFormationDansPanel(formation_id);
        }
    });

    // *********************************************************************************************
    // *** Génération de la liste des fiches d'un chapitre lorsqu'on clique sur son titre  *********
    // *********************************************************************************************
    // les balises ont été générées par ajax donc pas existantes sur le document.ready
    $(document).on('click', '#chapitresformation .card-header a[data-toggle="collapse"]', function(event) {
        // retrouve le card-body (anciennement panel-body) qui contient le chapitre_id et où la liste sera affichée
        // en remontant au panel puis en redescendant sur le panel-body qui est au même niveau que le panel-heading qui contient le lien
        var $panelbody = $(this).parents('.card:first').find('.card-body:first');

        // s'il y a une balise avec la classe encoursdegeneration dans un panel-body, c'est que la liste n'a pas été générée
        if ($panelbody.find('.encoursdegeneration').length) {
            // génère la liste
            listeFichesChapitreDansPanel($panelbody);
        }
    });

});
</script>

<?php wp_footer(); ?>

</body>

</html>