<?php get_header();?>

<div class="container">


    <div id="listefavoris">
    </div>


    <div id="dernierespagesvisitees">
    </div>

    <div class="contenuprincipal">
        <hr class="divider">
        <h1 id="titreh1" class="text-center"> Formation PUB020&nbsp;: WordPress, 2023
        </h1>
        <hr class="divider bas">

        <div class="contenu">
            <div id="chapitresformation" data-formation-id="36">

                <div class="boutonshaut">
                    <div class="float-left">
                    </div>
                    <div class="push"></div>
                </div>
                <div id="dragchapitres">
                    <?php
                    if (have_posts()) :
                        $counter = 1;
                        while (have_posts()) : the_post();
                        $comments = get_comments( array( 'post_id' => get_the_ID() ) );
                    ?>
                    <div class="post card border-bottom-0" id="chapitre-<?php echo get_the_ID(); ?>" onclick="afficheCommentaire(this)">

                        <div class="card-header" id="chapitre-choisir_les_outils_pour_developper_un_site_wordpress">
                            <a data-toggle="collapse"
                                <?php echo (count($comments) === 0) ? 'href="' . get_permalink() . '"' : ''; ?>>
                                <span class="titrealigneboutons"><?php echo $counter; ?>. <?php the_title(); ?></span>
                            </a>
                            <div class="float-right boutonsalignes">
                            </div>
                        </div>
                        <div class="collapse comments chapitre-<?php echo get_the_ID(); ?>" aria-expanded="false"
                            id="fichesduchapitre-choisir_les_outils_pour_developper_un_site_wordpress">
                            <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2990"
                                style="display: flex; flex-direction: column; margin-left: 20px;" data-id="2990">
                                <?php 
                                    $secondCounter = 1;
                                    foreach ( $comments as $comment ) :
                                ?>
                                <a class='card-body'
                                    href="<?php the_permalink() ?>"><?php echo $counter . '.' . $secondCounter . ' ' . $comment->comment_content; ?></a>
                                <?php
                                        $secondCounter++;
                                    endforeach;
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                            $counter++;
                        endwhile; 
                    endif;
                    ?>
                </div>
                <div class="boutonsbas"></div>
            </div>
        </div>

        <div class="push"></div>
    </div>

<script>
    function afficheCommentaire(parentDiv) {

    var childDiv = parentDiv.querySelector(".comments");
    if (childDiv) {
        childDiv.classList.toggle("show");
    }
    }
</script>

<?php get_footer(); ?>