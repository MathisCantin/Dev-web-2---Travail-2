<?php get_header();?>

<div class="container">


    <div id="listefavoris">
    </div>


    <div id="dernierespagesvisitees">
    </div>

    <div class="contenuprincipal">
        <hr class="divider">
        <h1 id="titreh1" class="text-center"> Formation PUB020&nbsp;: WordPress, 2023
        </h1>
        <hr class="divider bas">

        <div class="contenu">
            <div id="chapitresformation" data-formation-id="36">


                <div class="boutonshaut">
                    <div class="float-left">
                    </div>
                    <div class="push"></div>
                </div>
                <div id="dragchapitres">

                    <?php
                    if (have_posts()) :
                        $counter = 1;
                        while (have_posts()) : the_post();
                    ?>
                    <div class="card border-bottom-0" id="dragchapitre_<?php echo $counter; ?>">
                        <div class="card-header" id="chapitre-<?php echo sanitize_title(get_the_title()); ?>">
                            <a data-toggle="collapse" href="<?php the_permalink() ?>"
                                href="wordpress.html#fichesduchapitre-<?php echo sanitize_title(get_the_title()); ?>">
                                <span class="titrealigneboutons"><?php echo $counter; ?>. <?php the_title(); ?></span>
                            </a>
                            <div class="float-right boutonsalignes">
                                
                            </div>
                        </div>
                    </div>
                    <?php
                            $counter++;
                        endwhile; 
                    endif;
                    ?>

                </div>
                <div class="boutonsbas"></div>
            </div>
        </div>

        <div class="push"></div>
    </div>

    <div class="publicite baspage">
        <div class="pubhebergement">
            <p>Site fièrement hébergé chez <a href="http://www.a2hosting.com?aid=5ca65a17be949" target="_top">A2
                    Hosting</a>.</p>
            <p><a href="https://www.a2hosting.com?aid=5ca65a17be949&amp;bid=ed1c4a67" target="_top"><img
                        src="https://affiliates.a2hosting.com/accounts/default1/banners/ed1c4a67.jpg" alt="" title=""
                        width="728" height="90" /></a><img style="border:0"
                    src="https://affiliates.a2hosting.com/scripts/imp.php?aid=5ca65a17be949&amp;bid=ed1c4a67" width="1"
                    height="1" alt="" /></p>
        </div>
    </div>
</div>

<?php get_footer(); ?>