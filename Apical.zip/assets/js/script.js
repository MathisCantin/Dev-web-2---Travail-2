document.addEventListener('DOMContentLoaded', function() {
    const formulaireauthentification = document.getElementById('popupauthentification');

    const boutonAuthentification = document.getElementById('boutonAuthentification');
    boutonAuthentification.onclick = ouvrir;

    const boutonfermer = document.getElementById("boutonfermer");
    boutonfermer.onclick = fermer;

    function ouvrir(){
        formulaireauthentification.style.display = 'block';
    }

    function fermer(){
        formulaireauthentification.style.display = 'none';
    }
});
