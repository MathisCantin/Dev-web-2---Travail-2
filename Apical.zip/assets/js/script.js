document.addEventListener('DOMContentLoaded', function() {
    const boutonAuthentification = document.getElementById('boutonAuthentification');
    const formulaireauthentification = document.getElementById('popupauthentification');

    boutonAuthentification.addEventListener('click', function(event) {
        event.preventDefault();
        if (formulaireauthentification.style.display === 'none' || formulaireauthentification.style.display === '') {
            formulaireauthentification.style.display = 'block';
        } else {
            formulaireauthentification.style.display = 'none';
        }
    });
});
