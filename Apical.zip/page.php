<?php get_header(); ?>

<div class="container">
    <div id="listefavoris"></div>
    <div id="dernierespagesvisitees"></div>
    <div class="contenuprincipal">
        <div class="push"></div>
        <?php the_content(); ?>
    </div>
    <div class="push"></div>
</div>

<div class="publicite baspage">
    <div class="pubhebergement">
        <p>Site fièrement hébergé chez <a href="http://www.a2hosting.com?aid=5ca65a17be949" target="_top">A2Hosting</a>.
        </p>
        <p>
            <a href="https://www.a2hosting.com?aid=5ca65a17be949&amp;bid=ed1c4a67" target="_top"><img
                    src="https://affiliates.a2hosting.com/accounts/default1/banners/ed1c4a67.jpg" alt="" title=""
                    width="728" height="90" /></a><img style="border:0"
                src="https://affiliates.a2hosting.com/scripts/imp.php?aid=5ca65a17be949&amp;bid=ed1c4a67" width="1"
                height="1" alt="" />
        </p>
    </div>
</div>
</div>

<?php get_footer(); ?>