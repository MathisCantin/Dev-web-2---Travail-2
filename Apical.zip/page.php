<?php get_header(); ?>

<div class="container">
    <div id="listefavoris"></div>
    <div id="dernierespagesvisitees"></div>
    <div class="contenuprincipal">
        <div class="push"></div>
        <?php the_content(); ?>
    </div>
    <div class="push"></div>

<?php get_footer(); ?>